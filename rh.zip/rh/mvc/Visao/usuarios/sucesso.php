<meta http-equiv="refresh" content="5;URL='<?= URL_RAIZ . 'login' ?>'" />
<div class="center-block site text-center">
    <h1>Parabéns!</h1>
    <p>Usuário cadastrado com sucesso.</p>
    <p>Você será redirecionado para a página de login.</p>
</div>
