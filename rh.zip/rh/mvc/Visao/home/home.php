    <div class="container">

    <br>
        <div class="row" style="margin-bottom: 1%;">
            <div class="col-sm-6 mb-3 mb-sm-0">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Se candidate a vagas de programação</h5>
                        <p class="card-text">Venha trabalhar em uma das melhores empresas de programação, com
                            execelente salário e
                            participação em grandes projetos.<br>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                            has been
                            the industry's standard dummy text ever since the 1500s, when an unknown printer took a
                            galley
                            of type and scrambled it to make a type specimen book. It has survived not only five
                            centuries,
                            but also the leap into electronic typesetting, remaining essentially unchanged. It was
                            popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum
                            passages,
                            and more recently with desktop publishing software like Aldus PageMaker including
                            versions of
                            Lorem Ipsum.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6" style="width: 32rem;">
                <img src="../rh/publico/img/nyljaMX.png" class="card-img-top" alt="códigos caindo de uma nuvem">
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6 mb-3 mb-sm-0" style="width: 32rem;">
                <img src="../rh/publico/img/team.png" class="card-img-top" alt="...">
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Conheça nossa equipe</h5>
                        <p class="card-text">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Juninho0 -> Chefe </li>
                                <li class="list-group-item">Juninho2 -> RH </li>
                                <li class="list-group-item">Juninho2 -> Programador Front-End </li>
                                <li class="list-group-item">Juninho3 -> Programador Back-End</li>
                            </ul>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>