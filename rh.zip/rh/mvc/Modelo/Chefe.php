<?php
namespace Modelo;

use \PDO;
use \Framework\DW3BancoDeDados;
use \Framework\DW3Sessao;


class Chefe extends Usuario
{
    const BUSCAR_TODOS = 'SELECT * FROM usuarios WHERE tipo = "programador" AND situacao = "disponivel" OR situacao = "convidado"';
    const BUSCAR_CONVIDADOS = 'SELECT * FROM usuarios WHERE tipo = "programador" AND situacao = "aceite"';

    public static function buscarProgramadores()
    {
        $registros = null;
        $objetos = [];
        $objeto = null;

        $comando = DW3BancoDeDados::query(self::BUSCAR_TODOS);
        $registros = $comando->fetchAll();
        
        foreach ($registros as $registro) {
            
            $objetos[] = new Usuario(
                $registro['nome'],
                $registro['email'],
                '',
                $registro['tipo'],
                $registro['id'],
                $registro['situacao']
            );

        }

        return $objetos;
    }

}
