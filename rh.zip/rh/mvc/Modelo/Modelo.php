<?php
namespace Modelo;

use \Framework\DW3Modelo;

abstract class Modelo extends DW3Modelo
{
}
