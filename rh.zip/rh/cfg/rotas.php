<?php

$rotas = [
    '/' => [
        'GET' => '\Controlador\RaizControlador#index',
    ],
    '/login' => [
        'GET' => '\Controlador\LoginControlador#criar',
        'POST' => '\Controlador\LoginControlador#armazenar',
        'DELETE' => '\Controlador\LoginControlador#destruir',
    ],
    '/usuarios' => [
        'POST' => '\Controlador\UsuarioControlador#armazenar',
    ],
    '/usuarios/criar' => [
        'GET' => '\Controlador\UsuarioControlador#criar',
    ],
    '/usuarios/sucesso' => [
        'GET' => '\Controlador\UsuarioControlador#sucesso'
    ],
    '/programador/perfil' => [
        'GET' => '\Controlador\ProgramadorControlador#index',
        'POST' => '\Controlador\MensagemControlador#armazenar'
    ],

    '/chefe/listaConvite' => [
        'GET' => '\Controlador\ChefeControlador#index',
        'POST' => '\Controlador\ChefeControlador#armazenar'
    ],

    '/chefe/?/convidar' => [
        'POST' => '\Controlador\ChefeControlador#convidar'
    ],

    '/chefe/?/desconvidar' => [
        'POST' => '\Controlador\ChefeControlador#desconvidar'
    ],
    
    '/Rh/listaContratacao' => [
        'GET' => '\Controlador\RhControlador#index',
        'POST' => '\Controlador\MensagemControlador#armazenar',
    ],


    '/acaoUsuario/?' => [
        'POST' => '\controlador\UsuarioControlador#mudarSituacao'
    ],

    '/mensagens/?' => [
        'DELETE' => '\Controlador\MensagemControlador#destruir',
    ],

];
