<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'rh',
    'usuario' => 'root',
    'senha' => '',
];
