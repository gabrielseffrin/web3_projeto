<?php

require_once '../framework/DW3Carregador.php';

$testador = new \Framework\DW3Testador();
$testador->testarTudo();
