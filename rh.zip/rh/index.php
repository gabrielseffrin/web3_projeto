<?php

require_once '../framework/DW3Carregador.php';

$app = new \Framework\DW3Aplicacao();
$app->executar();
